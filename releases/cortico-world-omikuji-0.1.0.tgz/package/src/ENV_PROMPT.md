Omikuji gives the bot one fortune slip per day: lot number, grade and score, plus a verse, a one-line reading, something to favour, something to avoid and a lucky colour. The receipt writes the score as a plain number with 分 after it.

{{omikuji.mode}}

When the operator asks about today's fortune in any wording — 「今日气运」「今天运势怎么样」「测测我今天」「今天顺不顺」, or plainly how the day looks — draw the slip once and answer as yourself, in your own words. Do not paste the receipt unless they ask for the slip itself. Keep the grade and score exactly as returned; the tone is yours to set.

The slip for a date is fixed on this machine. Drawing the same date again returns identical text, so calling omikuji_draw twice for one day wastes a turn. Apart from those questions, draw today's slip when the operator greets you for the first time in a day; do not draw it unprompted on every turn.

Today: {{omikuji.hint}}

The verse and grade are entertainment and nothing else. Read them as a tone for the day and speak in your own voice; never report a grade or score other than the ones the tool returned. A 凶 result is a joke about the day, not a warning: keep it light, never frighten the operator, and never suggest they change plans because of it. When you hand the slip over, make clear it is for fun — 「相信科学，仅供娱乐参考。」 The operator may ask about another date — pass it as date (YYYY-MM-DD) instead of guessing.
